<?php
require get_template_directory() . '/framework/widgets/recent-news.php';
require get_template_directory() . '/framework/widgets/instagram.php';
require get_template_directory() . '/framework/widgets/flickr.php';
require get_template_directory() . '/framework/widgets/socials.php';
require get_template_directory() . '/framework/widgets/links.php';
require get_template_directory() . '/framework/widgets/spacer.php';
require get_template_directory() . '/framework/widgets/information.php';
require get_template_directory() . '/framework/widgets/contact-form-7.php';