		</div><!-- /.main-content -->

		<?php get_template_part( 'templates/footer-subscribe'); ?>

		<?php get_template_part( 'templates/footer-widgets'); ?>
		
		<?php get_template_part( 'templates/bottom'); ?>

	</div><!-- /#page -->
</div><!-- /#wrapper -->

<?php get_template_part( 'templates/scroll-top'); ?>
<?php wp_footer(); ?>
</body>
</html>